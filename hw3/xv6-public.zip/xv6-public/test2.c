#include "types.h"
#include "stat.h"
#include "user.h"

void prime_number_task(int limit, int pid, int nice_value) {
    int i, j, is_prime, count = 0;

    printf(1, "Process %d with initial nice value %d started\n", pid, nice_value);

    for (i = 2; count < limit; i++) {
        is_prime = 1;
        for (j = 2; j * j <= i; j++) {
            if (i % j == 0) {
                is_prime = 0;
                break;
            }
        }
        if (is_prime) {
            printf(1, "Process %d (nice %d) found prime: %d\n", pid, nice_value, i);
            count++;

            // Adjust priority after finding 5 primes
            if (count == 5) {
                if (nice_value == 5) {
                    nice(0, 1); // Increase priority for the first process
                    nice_value = 1;
                } else if (nice_value == 5) {
                    nice(0, 9); // Lower priority for the second process
                    nice_value = 9;
                }
                printf(1, "Process %d adjusted nice value to %d\n", pid, nice_value);
            }
        }
    }

    printf(1, "Process %d with final nice value %d finished\n", pid, nice_value);
}

int main() {
    int pid1, pid2, pid3;

    pid1 = fork();
    if (pid1 == 0) {
        nice(0, 5);
        prime_number_task(15, getpid(), 5);
        exit();
    }

    pid2 = fork();
    if (pid2 == 0) {
        nice(0, 5);
        prime_number_task(15, getpid(), 5);
        exit();
    }

    pid3 = fork();
    if (pid3 == 0) {
        nice(0, 5);
        prime_number_task(15, getpid(), 5);
        exit();
    }

    wait();
    wait();
    wait();

    exit();
}
